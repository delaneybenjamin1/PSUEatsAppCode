import Controller.RestaurantController;
import Model.Restaurant;
import View.DataEngine;

import java.util.ArrayList;

public class  App
{
    //main
    public static void main(String[] args)
    {
        //ArrayList<Restaurant> restaurants;
        //Restaurant theModel = new Restaurant();
       // RestaurantView theView = new RestaurantView();

        //RestaurantController c = new RestaurantController(theModel, theView);
        //theView.setVisible(true);
        DataEngine de = new DataEngine();
        ArrayList<Restaurant> restaurants = de.loadRestaurantData("/Users/delaneybenjamin/IdeaProjects/PSUeats/src/RestaurantText");
        RestaurantController restaurantController = new RestaurantController(restaurants);
    }
}