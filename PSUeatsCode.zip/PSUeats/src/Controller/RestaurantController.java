package Controller;
import java.util.ArrayList;

import Model.Restaurant;
import View.AddRestaurant;
import View.RestaurantPage;


public class RestaurantController
{


    //fields
        private RestaurantPage restaurantPage;

        public ArrayList<Restaurant> restaurants;

        //constructor
        public RestaurantController(ArrayList<Restaurant> restaurantsFromMain)
        {
            restaurants = restaurantsFromMain;
            restaurantPage = new RestaurantPage(this);

            restaurantPage.setSize(500, 500);
            restaurantPage.setTitle("PSU EATS");
            restaurantPage.setLocationRelativeTo(null);
            restaurantPage.setVisible(true);


        }


}
