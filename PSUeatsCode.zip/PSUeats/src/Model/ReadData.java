package Model;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ReadData extends JFrame
{
    public static ArrayList<Restaurant> readDataFile(String fileName)
    {
        ArrayList<Restaurant> restaurants = new ArrayList<Restaurant>();
        try{
            File data = new File(fileName);
            Scanner input = new Scanner(data);
            input.useDelimiter(",");
            while(input.hasNextLine())
            {
                Restaurant newRestaurant = new Restaurant();
                String[] record = input.nextLine().split(",");
                for(int x = 0; x < record.length-1; x++)
                {
                    newRestaurant.setName(record[0]);
                    newRestaurant.setLocation(record[1]);
                    newRestaurant.setDelivers(record[2]);
                    newRestaurant.setWebsite(record[3]);
                    newRestaurant.setHours(record[4]);
                    newRestaurant.setReview(record[5]);
                }
                restaurants.add(newRestaurant);
            }
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        for(Restaurant x :restaurants)
        {
            System.out.println(x.toString());
        }
        return restaurants;
    }

    public static void main(String[] args)
    {
        readDataFile("RestaurantText");
    }

}

