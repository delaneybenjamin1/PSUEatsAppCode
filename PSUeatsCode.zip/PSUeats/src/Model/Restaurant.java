package Model;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class Restaurant {
    //Fields
    private String name;
    private String location;
    private String delivers;
    private String website;
    private String hours;
    private String review;
    private int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void exit()
    {
        System.exit(0);
    }

    public Restaurant(){};



    //Constructor
    public Restaurant(String name, String location, String delivers, String website, String hours, String review, int ID)
    {
        this.name = name;
        this.location = location;
        this.delivers = delivers;
        this.website = website;
        this.hours = hours;
        this.review = review;
        this.ID = ID;

    }


    //Accessors
    public String getName()
    {
    return name;
    }


    public String getLocation() {
        return location;
    }

    public String getDelivers() {
        return delivers;
    }

    public String getWebsite()
    {
        return website;
    }

    public String getHours()
    {
        return hours;
    }

    public String getReview()
    {
        return review;
    }



    //Mutators
    public void setName(String name)
    {
        this.name = name;
    }

    public void setWebsite(String website)
    {
        this.website = website;
    }

    public void setHours(String hours)
    {
        this.hours = hours;
    }

    public void setReview(String review)
    {
        this.review = review;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public void setDelivers(String delivers) {
        this.delivers = delivers;
    }



    //toString
    @Override
    public String toString()
    {
        return "Restaurant Name: " + getName()  + "\nLocation: " + getLocation() + "\nDelivers: " + getDelivers() + "\nWebsite: " + getWebsite()
                + "\nHours: " + getHours() + "\nReviews: " + getReview();
    }
}
