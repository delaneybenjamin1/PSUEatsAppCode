package View;

import Controller.RestaurantController;
import Model.Restaurant;
import View.RestaurantPage;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddRestaurant extends JFrame {
    private JLabel AddRestaurant;
    private JTextField enterRestaurantNameTextField;
    private JTextField enterLocationTextField;
    private JTextField enterWebsiteTextField;
    private JButton saveButton;
    private JTextArea hoursTextArea;
    private JTextField enterRatingTextField;
    private JPanel addPanel;
    private JTextField deliversTextField;
    private JButton exitButton;
    private JButton deleteButton;
    private RestaurantController restaurantController;
    private RestaurantPage restaurantPage;
    private AddRestaurant addRestaurant;
    private int _ID;

    public JButton getExit2Button() {
        return exitButton;
    }

    public void setExit2Button(JButton exitButton) {
        this.exitButton = exitButton;
    }

    public void setDeleteButton(JButton deleteButton) {
        this.deleteButton = deleteButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public AddRestaurant(RestaurantController restaurantControllerIn, RestaurantPage restaurantPageIn)
    {
        this.restaurantController = restaurantControllerIn;
        this.restaurantPage = restaurantPageIn;
        this.setSize(1000,500);
        setContentPane(addPanel);
        setLocationRelativeTo(null);

        saveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e)
        {
            //if statement
            if(_ID == 0)
            {
                addNewRestaurant();
            }
            else
            {
                EditRestaurant();
            }

           save();
           restaurantPage.loadTable(restaurantController.restaurants);
           addRestaurant.dispose();

        }


        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRestaurant.dispose();
                DataEngine de = new DataEngine();
                de.saveData(restaurantController.restaurants, "RestaurantText");
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DeleteRestaurant();
                restaurantPage.loadTable(restaurantController.restaurants);
                addRestaurant.dispose();

            }
        });
    }
    public AddRestaurant(int ID, String Name, String Location, String Delivers, String Website, String Hours, String Review, RestaurantController restaurantControllerIn, RestaurantPage restaurantPageIn)
    {
        this.restaurantController = restaurantControllerIn;
        this.restaurantPage = restaurantPageIn;
        //this. addRestaurant = addRestaurantIn;
        _ID = ID;

        enterRestaurantNameTextField.setText(Name);
        enterLocationTextField.setText(Location);
        deliversTextField.setText(Delivers);
        enterWebsiteTextField.setText(Website);
        hoursTextArea.setText(Hours);
        enterRatingTextField.setText(Review);
        addRestaurant = this;

        this.setSize(1000,500);
        setContentPane(addPanel);
        setLocationRelativeTo(null);

        saveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //if statement
                if(_ID == 0)
                {
                    addNewRestaurant();
                }
                else
                {
                    EditRestaurant();
                }

                save();
                restaurantPage.loadTable(restaurantController.restaurants);
                addRestaurant.dispose();

            }


        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRestaurant.dispose();
                DataEngine de = new DataEngine();
                de.saveData(restaurantController.restaurants, "RestaurantText");
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DeleteRestaurant();
                restaurantPage.loadTable(restaurantController.restaurants);
                addRestaurant.dispose();
            }
        });

    }

    public void addNewRestaurant()
    {
        Restaurant newRestaurant = new Restaurant();

        ///newRestaurant.setID(999);
        newRestaurant.setID(restaurantPage.getRestaurantTable().getRowCount()+1);
        newRestaurant.setName(enterRestaurantNameTextField.getText());
        newRestaurant.setLocation(enterLocationTextField.getText());
        newRestaurant.setDelivers(deliversTextField.getText());
        newRestaurant.setWebsite(enterWebsiteTextField.getText());
        newRestaurant.setHours(hoursTextArea.getText());
        newRestaurant.setReview(enterRatingTextField.getText());

        restaurantController.restaurants.add(newRestaurant);
        //restaurantPage.loadTable(restaurantController.restaurants);
       // addRestaurant.dispose();
    }

    public void DeleteRestaurant()
    {
        for(Restaurant restaurant : restaurantController.restaurants)
        {
            if(restaurant.getID() == _ID)
            {
                restaurantController.restaurants.remove(restaurant);
                break;
            }
        }
    }

    public void save()
    {
        addRestaurant = this;
        Restaurant newRestaurant = new Restaurant();

        newRestaurant.setName(enterRestaurantNameTextField.getText());
        newRestaurant.setLocation(enterLocationTextField.getText());
        newRestaurant.setDelivers(deliversTextField.getText());
        newRestaurant.setWebsite(enterWebsiteTextField.getText());
        newRestaurant.setHours(hoursTextArea.getText());
        newRestaurant.setReview(enterRatingTextField.getText());

        //restaurantController.restaurants.add(newRestaurant);

        restaurantPage.loadTable(restaurantController.restaurants);


       //setVisible(false);
    }

    public void EditRestaurant()
    {
        for(Restaurant restaurant : restaurantController.restaurants)
        {
            if(restaurant.getID() == _ID)
            {
                restaurant.setName(enterRestaurantNameTextField.getText());
                restaurant.setWebsite(enterWebsiteTextField.getText());
                restaurant.setDelivers(deliversTextField.getText());
                restaurant.setLocation(enterLocationTextField.getText());
                restaurant.setHours(hoursTextArea.getText());
                restaurant.setReview(enterRatingTextField.getText());
                break;
            }
        }

    }
    public void setEnterRestaurantNameTextField(JTextField enterRestaurantNameTextField) {
        this.enterRestaurantNameTextField = enterRestaurantNameTextField;
    }

    public void setEnterLocationTextField(JTextField enterLocationTextField) {
        this.enterLocationTextField = enterLocationTextField;
    }

    public void setEnterWebsiteTextField(JTextField enterWebsiteTextField) {
        this.enterWebsiteTextField = enterWebsiteTextField;
    }

    public void setSaveButton(JButton saveButton) {
        this.saveButton = saveButton;
    }

    public void setHoursTextArea(JTextArea hoursTextArea) {
        this.hoursTextArea = hoursTextArea;
    }

    public void setEnterRatingTextField(JTextField enterRatingTextField) {
        this.enterRatingTextField = enterRatingTextField;
    }

    public void setAddPanel(JPanel addPanel) {
        this.addPanel = addPanel;
    }

    public void setDeliversTextField(JTextField deliversTextField) {
        this.deliversTextField = deliversTextField;
    }

    public JTextField getEnterRestaurantNameTextField() {
        return enterRestaurantNameTextField;
    }

    public JTextField getEnterLocationTextField() {
        return enterLocationTextField;
    }

    public JTextField getEnterWebsiteTextField() {
        return enterWebsiteTextField;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JTextArea getHoursTextArea() {
        return hoursTextArea;
    }

    public JTextField getEnterRatingTextField() {
        return enterRatingTextField;
    }

    public JPanel getAddPanel() {
        return addPanel;
    }

    public JTextField getDeliversTextField() {
        return deliversTextField;
    }


}
