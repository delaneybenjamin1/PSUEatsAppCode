package View;

import Controller.RestaurantController;
import Model.Restaurant;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class RestaurantPage extends JFrame
{

    private JPanel panel1;
    private JTable RestaurantTable;
    private JButton addReviewButton;
    private JButton exitButton;
    private JButton addRestaurantButton;
    private JLabel RestaurantListHeader;
    private JCheckBox onCampusCheckBox;
    private JCheckBox downtownCheckBox;
    private JCheckBox deliveryCheckBox;
    private JButton resetButton;
    private JButton editRestaurantButton;
    private RestaurantController restaurantController;
    private RestaurantPage restaurantPage;
    private int _ID;



    public RestaurantPage( RestaurantController restaurantControllerIn)
    {
        restaurantPage = this;
        restaurantController = restaurantControllerIn;
        loadTable(restaurantController.restaurants);
        RestaurantTable.removeColumn(RestaurantTable.getColumnModel().getColumn(6)); //remove column
        this.setContentPane(panel1);

        RestaurantTable.setAutoCreateRowSorter(true);
        RestaurantTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                _ID = 999;
                editRestaurant();
            }
        });

        addRestaurantButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                _ID = 0;
                AddRestaurant apiUI = new AddRestaurant(restaurantController, restaurantPage);
                apiUI.setVisible(true);
                loadTable(restaurantController.restaurants);
            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveData(restaurantController.restaurants, "/Users/delaneybenjamin/IdeaProjects/PSUeats/src/RestaurantText");
                System.exit(0);
            }
        });
        deliveryCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(deliveryCheckBox.isSelected()) && onCampusCheckBox.isSelected())
                {
                    updateOnCampus(restaurantController.restaurants);
                }
                else if(!(deliveryCheckBox.isSelected()) && downtownCheckBox.isSelected())
                {
                    updateDowntown(restaurantController.restaurants);
                }
                else if(!(deliveryCheckBox.isSelected()))
                {
                    loadTable(restaurantController.restaurants);
                }
                else {

                    if (downtownCheckBox.isSelected())
                    {
                        updateBothDowntown(restaurantController.restaurants);
                    }
                    else if (onCampusCheckBox.isSelected())
                    {
                        updateBothOnCampus(restaurantController.restaurants);
                    }
                    else
                    {
                        updateDelivers(restaurantController.restaurants);
                    }
                }
            }
        });
        onCampusCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(deliveryCheckBox.isSelected() && !(onCampusCheckBox.isSelected()))
                {
                    updateDelivers(restaurantController.restaurants);
                }
                else if(!(onCampusCheckBox.isSelected()))
                {
                    loadTable(restaurantController.restaurants);
                }
                else {

                    if(deliveryCheckBox.isSelected())
                    {
                        updateBothOnCampus(restaurantController.restaurants);
                    }
                    else
                    {
                        updateOnCampus(restaurantController.restaurants);
                    }
                }
            }

        });
        downtownCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(deliveryCheckBox.isSelected() && !(downtownCheckBox.isSelected()))
                {
                    updateDelivers(restaurantController.restaurants);
                }
                else if(!(downtownCheckBox.isSelected()))
                {
                    loadTable(restaurantController.restaurants);
                }
                else {
                    if (deliveryCheckBox.isSelected()) {
                        updateBothDowntown(restaurantController.restaurants);
                    } else {
                        updateDowntown(restaurantController.restaurants);
                    }
                }
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadTable(restaurantController.restaurants);
                deliveryCheckBox.setSelected(false);
                downtownCheckBox.setSelected(false);
                onCampusCheckBox.setSelected(false);
            }
        });
    }

    public void updateDelivers(ArrayList<Restaurant> restaurants)
    {
        ArrayList<Restaurant> restaurantSort = new ArrayList<>();
        String delivery;
        for(Restaurant restaurant: restaurants)
        {
            delivery = restaurant.getDelivers();
            if (delivery.contains("yes") || delivery.contains("Yes"))
            {
                restaurantSort.add(restaurant);
            }
        }
        loadTable(restaurantSort);
    }
    public void updateOnCampus(ArrayList<Restaurant> restaurants)
    {
        ArrayList<Restaurant> restaurantSort = new ArrayList<>();
        String update;
        for(Restaurant restaurant: restaurants)
        {
            update = restaurant.getLocation();
            if (update.contains("On Campus") || update.contains("on campus"))
            {
                restaurantSort.add(restaurant);
            }
        }
        loadTable(restaurantSort);
        downtownCheckBox.setSelected(false);
    }

    public void updateDowntown(ArrayList<Restaurant> restaurants)
    {
        ArrayList<Restaurant> restaurantSort = new ArrayList<>();
        String update;
        for(Restaurant restaurant: restaurants)
        {
            update = restaurant.getLocation();
            if (update.contains("Downtown") || update.contains("downtown"))
            {
                restaurantSort.add(restaurant);
            }
        }
        loadTable(restaurantSort);
        onCampusCheckBox.setSelected(false);
    }
    public void updateBothDowntown(ArrayList<Restaurant> restaurants)
    {
        ArrayList<Restaurant> restaurantSort = new ArrayList<>();
        String update;
        String delivery;
        for(Restaurant restaurant: restaurants)
        {
            update = restaurant.getLocation();
            delivery = restaurant.getDelivers();
            if ((update.contains("Downtown") || update.contains("downtown")) && (delivery.contains("yes") || delivery.contains("Yes")))
            {
                restaurantSort.add(restaurant);
            }
        }
        loadTable(restaurantSort);
        onCampusCheckBox.setSelected(false);
    }
    public void updateBothOnCampus(ArrayList<Restaurant> restaurants)
    {
        ArrayList<Restaurant> restaurantSort = new ArrayList<>();
        String update;
        String delivery;
        for(Restaurant restaurant: restaurants)
        {
            update = restaurant.getLocation();
            delivery = restaurant.getDelivers();
            if ((update.contains("On Campus") || update.contains("on campus")) && (delivery.contains("yes") || delivery.contains("Yes")))
            {
                restaurantSort.add(restaurant);
            }
        }
        loadTable(restaurantSort);
        downtownCheckBox.setSelected(false);
    }

    public void loadTable(ArrayList<Restaurant> restaurants)
    {
        String headers[] = {"Name", "Location", "Delivers", "Website", "Hours", "Reviews","ID"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(headers);
        for(Restaurant restaurant : restaurants)
        {
            model.addRow(new Object[]
                    {
                            restaurant.getName(),
                            restaurant.getLocation(),
                            restaurant.getDelivers(),
                            restaurant.getWebsite(),
                            restaurant.getHours(),
                            restaurant.getReview(),
                            restaurant.getID()
                    });
        }
        RestaurantTable.setModel(model);
    }

    public void editRestaurant()
    {
        int selectedRow = RestaurantTable.getSelectedRow();

        String Name;
        String Location;
        String Delivers;
        String Website;
        String Hours;
        String Reviews;
        int ID = 0;

        Name = (String)RestaurantTable.getValueAt(selectedRow, 0);
        Location = (String)RestaurantTable.getValueAt(selectedRow, 1);
        Delivers = (String)RestaurantTable.getValueAt(selectedRow, 2);
        Website = (String)RestaurantTable.getValueAt(selectedRow, 3);
        Hours = (String)RestaurantTable.getValueAt(selectedRow, 4);
        Reviews = RestaurantTable.getValueAt(selectedRow, 5).toString();
        ID = (int)RestaurantTable.getModel().getValueAt(selectedRow, 6);


        AddRestaurant apiUI = new AddRestaurant(ID, Name, Location, Delivers, Website, Hours, Reviews, restaurantController, this);
        apiUI.setVisible(true);
    }

    public boolean saveData(ArrayList<Restaurant>restaurants, String fileName)
    {
        try
        {
            BufferedWriter bw = new
            BufferedWriter (new FileWriter(fileName));
            for(Restaurant restaurant: restaurants)
            {
                String dataToWrite =
                        restaurant.getName() + "," + restaurant.getLocation() + "," + restaurant.getDelivers()
                                + "," + restaurant.getWebsite() + "," + restaurant.getHours() + "," + restaurant.getReview();
                //bw.write("\n" + dataToWrite);
                bw.write( dataToWrite + "\n");

            }
            bw.close();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
    }





    //form
    public JPanel getPanel1() {
        return panel1;
    }

    public JTable getRestaurantTable() {
        return RestaurantTable;
    }

    public JButton getAddReviewButton() {
        return addReviewButton;
    }

    public JButton getExitButton() {
        return exitButton;
    }

    public JButton getAddRestaurantButton() {
        return addRestaurantButton;
    }

    public JLabel getRestaurantListHeader() {
        return RestaurantListHeader;
    }

    public JButton getEditRestaurantButton() {
        return editRestaurantButton;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public void setRestaurantTable(JTable restaurantTable) {
        RestaurantTable = restaurantTable;
    }

    public void setAddReviewButton(JButton addReviewButton) {
        this.addReviewButton = addReviewButton;
    }

    public void setExitButton(JButton exitButton) {
        this.exitButton = exitButton;
    }

    public void setAddRestaurantButton(JButton addRestaurantButton) {
        this.addRestaurantButton = addRestaurantButton;
    }

    public void setRestaurantListHeader(JLabel restaurantListHeader) {
        RestaurantListHeader = restaurantListHeader;
    }

    public ArrayList<Restaurant> restaurants;

    public void setEditRestaurantButton(JButton editRestaurantButton) {
        this.editRestaurantButton = editRestaurantButton;
    }

    public void setRestaurantController(RestaurantController restaurantController) {
        this.restaurantController = restaurantController;
    }
}
