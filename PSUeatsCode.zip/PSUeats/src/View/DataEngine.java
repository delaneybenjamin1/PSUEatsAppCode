package View;

import Model.Restaurant;

import javax.swing.*;
import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;
//"/Users/delaneybenjamin/Desktop/Sophomore Year/RestaurantList.csv"

public class DataEngine
{
    public ArrayList<Restaurant> loadRestaurantData(String fileName) {
        ArrayList<Restaurant> restaurants = new ArrayList<Restaurant>();
        Scanner input;
        try {
            File data = new File(fileName);
            input = new Scanner(data);
            int q = 1;
            input.useDelimiter(",");
            while ((input.hasNextLine())) {
                Restaurant newRestaurant = new Restaurant();
                String[] record = input.nextLine().split(",");
              //  input.nextLine();
                newRestaurant.setID(q);
                q++;
                for (int x = 0; x < record.length - 1; x++) ;
                {
                    newRestaurant.setName(record[0]);
                    newRestaurant.setLocation(record[1]);
                    newRestaurant.setDelivers(record[2]);
                    newRestaurant.setWebsite(record[3]);
                    newRestaurant.setHours(record[4]);
                    newRestaurant.setReview(record[5]);
                }
                restaurants.add(newRestaurant);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return restaurants;
    }


        public boolean saveData(ArrayList<Restaurant> restaurants, String fileName)
        {
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));

                for (Restaurant restaurant : restaurants) {
                    String dataToWrite = restaurant.getName() + "," + restaurant.getLocation() + "," + restaurant.getDelivers() + "," + restaurant.getWebsite() + "," + restaurant.getHours() + "," + restaurant.getReview();
                    bw.write("\n" + dataToWrite);
                }
                bw.close();
            }
            catch(IOException ex) {
                System.out.println(ex.getMessage());
                return false;
            }
            return true;
        }
}
